
$(document).ready(function(){

 var genratenumber = "";

var getnumber = window.location.href.split("+")[1];

var genratenum = getnumber.split("=");
        genratenumber = genratenum[1];

GetDetail(genratenumber);

viewData(genratenumber);

});

function GetDetail(genratenumberdyn)
{

var row = "";
var url =_spPageContextInfo.webAbsoluteUrl+"/_api/Web/Lists/GetByTitle('LeadGenerate')/Items?$select=*,ID,Opportunity,LeadGenerateNumber,ProjectName,ClientName,ProjectDescription,Notes,Budget,LeadGenerationDate,Author/Title,Author/Name,Author/EMail,AttachmentFiles&$expand=Author/EMail,AttachmentFiles&$filter=LeadGenerateNumber eq '"+ genratenumberdyn+"'";
   
    $.ajax({
       
        url: url,
        method:"GET",
        headers: {
             "Accept": "application/json;odata=verbose",  
            "Content-Type": "application/json;odata=verbose"  
            
     },
     success: function(data)
{
var result = data.d.results;

for (var i = 0; i < data.d.results.length; i++) {
                                    //var AttachmentFiles = data.d.result[i].ServerRelativeUrl;
                                    
                                    if(data.d.results[i].AttachmentFiles.results.length > 0){
                                    var AttachmentFiles = data.d.results[i].AttachmentFiles.results[i].ServerRelativeUrl;
                                    $("#img").append('<img src="'+AttachmentFiles+'" alt="team member" class="img-full" data-themekey="#" >');
                                    }
                                    
                                    else {
                                      $("#img").append('<img  src="https://awcsoftwarenoida.sharepoint.com/sites/SalesCRM_UAT/SiteAssets/Webparts/img/ProjectImg.png" alt="team member" class="img-full" data-themekey="#" >');
                                      } 
                                    
                                    
                                    var LeadGenerateNumber = data.d.results[i].LeadGenerateNumber;
                                    var Account = data.d.results[i].Account;   
                                    var Opportunity = data.d.results[i].Opportunity;
                                    var ProjectDescription = data.d.results[i].ProjectDescription;
                                    var ProjectName = data.d.results[i].ProjectName;
                                    var CurrentEngagement = data.d.results[i].CurrentEngagement;
                                    var EngagementType= data.d.results[i].EngagementType;
                                    var SPOCName= data.d.results[i].SPOCName;
                                    var EmailID= data.d.results[i].EmailID;
                                    var ContactNo= data.d.results[i].ContactNo;
                                    var Created= data.d.results[i].Author.Title;
                                    var Budget= data.d.results[i].Budget;
                                    var Notes= data.d.results[i].Notes;
                                    var LeadGenerationDate= data.d.results[i].LeadGenerationDate;
                                   
                                    id = data.d.results[i].ID;

$("#leadershipHeading").append(LeadGenerateNumber);
$("#getaccount").append(Account);
$("#getOpportunity").append(Opportunity);
$("#getProjectDesc").append(ProjectDescription);
$("#getProjectname").append(ProjectName);
$("#getcurEng").append(CurrentEngagement);
$("#getcurType").append(EngagementType);
$("#getsPOCname").append(SPOCName);
$("#getEmal").append(EmailID);
$("#getPhone").append(ContactNo);
$("#getName").append(Created);
$("#getclientBudget").append(Budget);
$("#getnote").append(Notes);
$("#leadershipHeading").append(LeadGenerationDate);
    
}
},

error: function(data)
{
//alert("Failed to get list items.");
}
});
}



// popup function call

function viewData(number){


var requestUri = _spPageContextInfo.webAbsoluteUrl +"/_api/web/lists/getByTitle('LeadGenerateDocuments')/items?$select=LeadGenerateNumber,Id,Title,File/ServerRelativeUrl,File/Name&$expand=File&$filter=LeadGenerateNumber eq '" + number + "'";
var requestHeaders = {
    "accept": "application/json;odata=verbose"
}

$.ajax({
    url: requestUri,
    type: 'GET',
    dataType: 'json',
    headers: requestHeaders,
    success: function (data) 
    {      
	$('#tblView2').empty();
	//$('#tblhead').empty();
	
	
    for (var i = 0; i < data.d.results.length; i++){ 
           
      var leadGenerateNumber = data.d.results[i].LeadGenerateNumber;
      var leadGenerateName = data.d.results[i].File.Name;
      var leadGenerateServerRelativeUrl = data.d.results[i].File.ServerRelativeUrl;
        
               
        
        
        
        $("#tblViewbind").append("<tr><td>"+leadGenerateNumber+"</td><td><a href="+leadGenerateServerRelativeUrl+" target='_blank'>"+leadGenerateName+"</a></td></tr>");
        }
      }
         });

 }

    error: function ajaxError(response) {
        alert(response.status + ' ' + response.statusText);
    }
    
    
    
 
 