var leadGenerateNumber="";

$(document).ready(function(){
/*initializePeoplePicker("txtleadowner");*/
AutoGenerate();


$("#submit").click(function () { 
 //SubmitFromLib();
 Submit();
 
 });
 
});


function AutoGenerate() {
  var min = 1;
  var max = 999;
  var num = Math.floor(Math.random() * (max - min + 1)) + min;
  var timeNow = new Date().getTime();
  document.getElementById('txtleadgn').value = num + '' + timeNow;
}
window.onload = AutoGenerate;
setTimeout(function () {
  console.log(document.getElementById('txtleadgn').value);
}, 500);



// This function have given to html onclick=”Post()”
function Submit()    
 {
    var leadGenerateNumber =$("#txtleadgn").val();
    var account =$("#txtaccount").val();
    var opportunity =$("#ddlopportunity").val();
    var projectName = $("#txtprojectname").val();
    var projectDescription = $("#txtprojectdricp").val();
    var currentEngagement =$("#txtcureentEng").val();
    var engagementType =$("#ddlcontactType").val();
    var sPOCName =$("#txtspocName").val();
    var emailID =$("#txtEmail").val();
    var contactNo =$("#txtcontact").val();   
    var budget = $("#txtbudget").val();
    var clientName= $("#txtclientname").val();
    var notes = $("#txtnotes").val();
    var leadGenerationDate = $("#leadGdate").val();  
    $(".loader").show();
    
      var URL = _spPageContextInfo.webAbsoluteUrl + "/_api/Web/Lists/GetByTitle('LeadGenerate')/Items";
    $.ajax({
        url: URL,
        type: "POST",
        data: JSON.stringify({
            __metadata: {
                type: "SP.Data.LeadGenerateListItem"  
            },

            LeadGenerateNumber : leadGenerateNumber , //(variable)
            Account : account,
            Opportunity :opportunity,
            ProjectName: projectName ,
            ProjectDescription : projectDescription ,
            CurrentEngagement:currentEngagement,
            EngagementType:engagementType,
            SPOCName:sPOCName,
            EmailID:emailID,
            ContactNo:contactNo,
            Budget:budget,
            ClientName:clientName,
            Notes:notes,
            LeadGenerationDate: leadGenerationDate,
                   
        }),
        headers: {
            "Accept": "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "X-RequestDigest": $("#__REQUESTDIGEST").val(),
            "X-HTTP-Method": "POST"
        },
        
        /*beforeSend:function(){
          //alert("xyz");
          
        
        },*/
      
    	
        //Disabled button 
        success: function(data, status, xhr) {
            
            $(".loader").hide();
            leadGenerateNumber =$("#txtleadgn").val();
            SubmitFromLib();
            
            //alert("Item added successfully");  
        },
        error: function(xhr, status, error) {
            alert("failed");
        }
    });
}


// Upload the file.
// You can upload files up to 2 GB with the R	EST API.
function SubmitFromLib() {
  // Define the folder path for this example.
  var serverRelativeUrlToFolder = 'LeadGenerateDocuments'; //Document Libary
  // Get test values from the file input and text input page controls.
  var fileInput = $('#myfile');
  var newName = jQuery('#renamefile').val();
  var leadGenerateNumber =$("#txtleadgn").val(); //Column of libary
  //var newName = jQuery('#overviewTitle').val();
 // Get the server URL.
  var serverUrl = _spPageContextInfo.webAbsoluteUrl;
 // Initiate method calls using jQuery promises.
 // Get the local file as an array buffer.
  var getFile = getFileBuffer();
  getFile.done(function (arrayBuffer) {
    // Add the file to the SharePoint folder.
  var addFile = addFileToFolder(arrayBuffer);
  addFile.done(function (file, status, xhr) {
      // Get the list item that corresponds to the uploaded file.
  var getItem = getListItem(file.d.ListItemAllFields.__deferred.uri);
  getItem.done(function (listItem, status, xhr) {
        // Change the display name and title of the list item.
  var changeItem = updateListItem(listItem.d.__metadata);
  	changeItem.done(function (data, status, xhr) {
          //alert('file uploaded and updated');
           alert("Item Added Successfully");
           location.reload();
           //--For redirect
          //window.location.href = "https://industowers.sharepoint.com/sites/myindus/Pages/get-overview.aspx";
        });
        changeItem.fail(onError);
      });
      getItem.fail(onError);
    });
    addFile.fail(onError);
  });
  getFile.fail(onError);
 // Get the local file as an array buffer.
function getFileBuffer() {
    var deferred = jQuery.Deferred();
    var reader = new FileReader();
    reader.onloadend = function (e) {
      deferred.resolve(e.target.result);
    }
    reader.onerror = function (e) {
      deferred.reject(e.target.error);
    }
    reader.readAsArrayBuffer(fileInput[0].files[0]);
    return deferred.promise();
  }
 // Add the file to the file collection in the Shared Documents folder.
function addFileToFolder(arrayBuffer) {
    // Get the file name from the file input control on the page.
    var parts = fileInput[0].value.split('\\');
    var fileName = parts[parts.length - 1];
   // Construct the endpoint.
    var fileCollectionEndpoint = String.format(
            "{0}/_api/web/getfolderbyserverrelativeurl('{1}')/files" +
            "/add(overwrite=true, url='{2}')",
            serverUrl, serverRelativeUrlToFolder, fileName);
     // Send the request and return the response.
    // This call returns the SharePoint file.
    return jQuery.ajax({
        url: fileCollectionEndpoint,
        type: "POST",
        data: arrayBuffer,
        processData: false,
        headers: {
          "accept": "application/json;odata=verbose",
          "X-RequestDigest": jQuery("#__REQUESTDIGEST").val(),
          "content-length": arrayBuffer.byteLength
        }
    });
  }
 // Get the list item that corresponds to the file by calling the file's ListItemAllFields property.
function getListItem(fileListItemUri) {
    // Send the request and return the response.
    return jQuery.ajax({
      url: fileListItemUri,
      type: "GET",
      headers: { "accept": "application/json;odata=verbose" }
    });
  }
 // Change the display name and title of the list item.
function updateListItem(itemMetadata) { 
    // Define the list item changes. Use the FileLeafRef property to change the display name.
    // For simplicity, also use the name as the title.
    // The example gets the list item type from the item's metadata, but you can also get it from the
    // ListItemEntityTypeFullName property of the list.
    var body = String.format("{{'__metadata':{{'type':'{0}'}},'FileLeafRef':'{1}','LeadGenerateNumber':'{2}'}}",
        itemMetadata.type, newName, leadGenerateNumber);    
   // Send the request and return the promise.
    // This call does not return response content from the server.
    return jQuery.ajax({
        url: itemMetadata.uri,
        type: "POST",
        data: body,
        headers: {
          "X-RequestDigest": jQuery("#__REQUESTDIGEST").val(),
          "content-type": "application/json;odata=verbose",
          "content-length": body.length,
          "IF-MATCH": itemMetadata.etag,
          "X-HTTP-Method": "MERGE"
        }
    });
  }
}
// Display error messages.
function onError(error) {
  alert(error.responseText);
}




















