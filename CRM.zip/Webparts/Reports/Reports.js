$(document).ready(function(){
 
GetDetail();


$("#btnupdate").click(function(){
   
 viewDate();
 	
});

});



function GetDetail()
{
var arrloc = [];
var row = '';
var url =_spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getByTitle('LeadGenerate')/items?select=Account,LeadGenerateNumber";
   
    $.ajax({
       
        url: url,
        method:"GET",
        headers: {
             "Accept": "application/json;odata=verbose",  
            "Content-Type": "application/json;odata=verbose"  
            
     },
     success: function(data)
{
var result = data.d.results;

for (var i = 0; i < data.d.results.length; i++) {
                                    var account = data.d.results[i].Account;   
                                    arrloc.push(account);
                                    console.log(arrloc);                                
                                    //id = data.d.results[i].ID;
                                    arrloc = $.unique(arrloc);
                                    
                                    
                                    var unique = $.grep(arrloc, function (item, index) {
                                    return index === $.inArray(item, arrloc);
});

}


for (var j = 0; j < unique.length; j++) {
    
              var accounts = unique[j]; 
               

row = row + "<tr><td>"+accounts+"</td><td><a onclick='viewDate(\""+ accounts + "\")'  ><span class='fa fa-eye' class='btn btn-primary' data-bs-toggle='modal' data-bs-target='#exampleModal'></span></a></td></tr>";
                                                                            
$("#tblView>tbody").html(row);

}



$("#tblView").show();
$('#tblView').DataTable();
},

error: function(data)
{
//alert("Failed to get list items.");
}
});
}



// popup function call

function viewDate(projname){

var Url = _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getByTitle('LeadGenerate')/items?select=Account,ProjectName,LeadGenerateNumber&$filter=Account eq '"+ projname +"'";  
//var Url = _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getByTitle('LeadGenerate')/items?select=Account,ProjectName,LeadGenerateNumber";  

    $.ajax({  
        url: Url,
        type:"GET",
        headers: {  
            Accept: "application/json;odata=verbose"  
        },  
        async: false,  
        success: function (data) {
        $('#tblView2').empty();

        if(data.d.results.length>0){//item count check   
	      for (var i = 0 ;i < data.d.results.length; i++)
			    {
           var account = data.d.results[i].Account ;
           var projectName = data.d.results[i].ProjectName ;
           var leadgeneratenumber = data.d.results[i].LeadGenerateNumber;
                                 
           $("#tblView1").append("<tr><td>"+leadgeneratenumber+"</td><td>"+projectName+"</td><td><a href='https://awcsoftwarenoida.sharepoint.com/sites/SalesCRM_UAT/Pages/Project-Details.aspx?+LeadGenrateNumber=" + leadgeneratenumber + "' target='_blank' ><span class='fa fa-eye' ></span></a></td></tr>");
                   }  
        }
         else
      {    
		    $("#tblView1").append("<h5>No Records Found ....!!</h5>");
		   
		      console.log("Record not Found");      
		      } 

       }, 
   error: function (xhr) 
   		{ 
   			if(xhr.statusText == 500)
   				{
   				   console.log(xhr.status + ': ' + xhr.statusText);
    			   console.log("Error")
				}
		    else
		      	{
		      		console.log(xhr.statusText + ': ' + xhr.status);
				    console.log("Data Access URL is Incorrect")			    
   		        }
		      
   		} 
}); 

}    
 
 






