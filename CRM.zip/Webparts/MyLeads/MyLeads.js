
$(document).ready(function(){

GetDetail();

$("#btnupdate").click(function(){ 
 updatestatus();
 	
});

$(document).on("click", ".delete", function() {

});
        
});

function GetDetail()
{

var row = "";
var url =_spPageContextInfo.webAbsoluteUrl+"/_api/Web/Lists/GetByTitle('LeadGenerate')/Items?$select=*,ID,Opportunity,LeadGenerateNumber,ProjectName,ClientName,ProjectDescription,Notes,Budget,LeadGenerationDate,Author/Title,Author/Name,Author/EMail&$expand=Author/EMail&$filter=Author/EMail eq '"+ _spPageContextInfo.userEmail+"'";
   
    $.ajax({
       
        url: url,
        method:"GET",
        headers: {
             "Accept": "application/json;odata=verbose",  
            "Content-Type": "application/json;odata=verbose"  
            
     },
     success: function(data)
{
var result = data.d.results;

for (var i = 0; i < data.d.results.length; i++) {
    
                                    var LeadGenerateNumber = data.d.results[i].LeadGenerateNumber;
                                    var Account = data.d.results[i].Account;   
                                    var Opportunity = data.d.results[i].Opportunity;
                                    var ProjectDescription = data.d.results[i].ProjectDescription;
                                    var ProjectName = data.d.results[i].ProjectName;
                                    var CurrentEngagement = data.d.results[i].CurrentEngagement;
                                    var EngagementType= data.d.results[i].EngagementType;
                                    var SPOCName= data.d.results[i].SPOCName;
                                    var EmailID= data.d.results[i].EmailID;
                                    var ContactNo= data.d.results[i].ContactNo;
                                    var Created= data.d.results[i].Author.Title;
                                    var Budget= data.d.results[i].Budget;
                                    var Notes= data.d.results[i].Notes;
                                    var LeadGenerationDate= data.d.results[i].LeadGenerationDate;
                                   
                                    id = data.d.results[i].ID;

   if (Opportunity == 'Hold' ){
row = row + '<tr><td>'+LeadGenerateNumber+'</td><td>'+Account+'</td><td>'+Opportunity+'</td><td>'+ProjectDescription+'</td><td>'+ProjectName+'</td><td>'+CurrentEngagement+'</td><td>'+EngagementType+'</td><td>'+SPOCName+'</td><td>'+EmailID+'</td><td>'+ContactNo+'</td><td>'+Created+'</td><td>'+Budget+'</td><td>'+Notes+'</td><td>'+LeadGenerationDate+'</td><td><a onclick="viewData(' + LeadGenerateNumber + ')"><span class="fa fa-eye" data-bs-toggle="modal" data-bs-target="#exampleModal" ></span></a></td><td><select id="abc" ><option>Select</option><option>Closed</option><option>Cancelled</option><option>Hold</option><option>Open</option></select></td><td><a onclick="updatestatus(' + id + ')" ><button type="button" style="border-radius: 30px;height: 25px;padding: 0px;background: green;color: white;" >Update</button></a></td></tr>';
                } 
   else if (Opportunity == 'Open' ){
row = row + '<tr><td>'+LeadGenerateNumber+'</td><td>'+Account+'</td><td>'+Opportunity+'</td><td>'+ProjectDescription+'</td><td>'+ProjectName+'</td><td>'+CurrentEngagement+'</td><td>'+EngagementType+'</td><td>'+SPOCName+'</td><td>'+EmailID+'</td><td>'+ContactNo+'</td><td>'+Created+'</td><td>'+Budget+'</td><td>'+Notes+'</td><td>'+LeadGenerationDate+'</td><td><a onclick="viewData(' + LeadGenerateNumber + ')"><span class="fa fa-eye" data-bs-toggle="modal" data-bs-target="#exampleModal" ></span></a></td><td><select id="abc" ><option>Select</option><option>Closed</option><option>Cancelled</option><option>Hold</option><option>Open</option></select></td><td><a onclick="updatestatus(' + id + ')" ><button type="button" style="border-radius: 30px;height: 25px;padding: 0px;background: green;color: white;" >Update</button></a></td></tr>';
                } 
                else {
row = row + '<tr><td>'+LeadGenerateNumber+'</td><td>'+Account+'</td><td>'+Opportunity+'</td><td>'+ProjectDescription+'</td><td>'+ProjectName+'</td><td>'+CurrentEngagement+'</td><td>'+EngagementType+'</td><td>'+SPOCName+'</td><td>'+EmailID+'</td><td>'+ContactNo+'</td><td>'+Created+'</td><td>'+Budget+'</td><td>'+Notes+'</td><td>'+LeadGenerationDate+'</td><td><a onclick="viewData(' + LeadGenerateNumber + ')"><span class="fa fa-eye" data-bs-toggle="modal" data-bs-target="#exampleModal" ></span></a></td><td><select style="pointer-events: none;opacity: 0.5;" ><option>'+Opportunity+'</option></select></td><td><button  type="button" style="border-radius: 30px;height: 25px;padding: 0px;background: red;color: white;pointer-events: none;opacity: 0.3;">Update</button></td></tr>';
                }                                                                  


$("#tblView>tbody").html(row);}


$("#tblView").show();
$('#tblView').DataTable();
},

error: function(data)
{
//alert("Failed to get list items.");
}
});
}



// popup function call

function viewData(test){


var requestUri = _spPageContextInfo.webAbsoluteUrl +"/_api/web/lists/getByTitle('LeadGenerateDocuments')/items?$select=LeadGenerateNumber,Id,Title,File/ServerRelativeUrl,File/Name&$expand=File&$filter=LeadGenerateNumber eq '" + test + "'";
var requestHeaders = {
    "accept": "application/json;odata=verbose"
}

$.ajax({
    url: requestUri,
    type: 'GET',
    dataType: 'json',
    headers: requestHeaders,
    success: function (data) 
    {      
	$('#tblView2').empty();
	//$('#tblhead').empty();
	
	
    for (var i = 0; i < data.d.results.length; i++){ 
           
      var leadGenerateNumber = data.d.results[i].LeadGenerateNumber;
      var leadGenerateName = data.d.results[i].File.Name;
      var leadGenerateServerRelativeUrl = data.d.results[i].File.ServerRelativeUrl;
      var ID = data.d.results[i].Id;//For Delete

        
               
        
        
        
        $("#tblView2").append("<tr><td>"+leadGenerateNumber+"</td><td><a href="+leadGenerateServerRelativeUrl+" target='_blank'>"+leadGenerateName+"</a></td><td><a onclick='deleteDocument("+ID+")'> <span class='fa fa-remove' data-bs-toggle='modal' data-bs-target='#exampleModal'></span></a></td></tr>");
        }
      }
         });

 }

    error: function ajaxError(response) {
        alert(response.status + ' ' + response.statusText);
    }
    
    
    
 
 function updatestatus(updateitemid){
 //var opportunity = $("#updatedop").text();
 var opportunity = $("#abc option:selected").text();
 
 if (opportunity == 'Select'){
    alert ("Please select Opportunity")
 }
 else{
 var URL = _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getByTitle('LeadGenerate')/Items("+updateitemid+")";
 $.ajax({
        url: URL,
        type: 'POST',
        async:false,
        headers: {
            "Accept": "application/json;odata=verbose",
            "Content-Type": "application/json;odata=verbose",
            "X-RequestDigest": $("#__REQUESTDIGEST").val(),
            "IF-MATCH": "*",
            "X-HTTP-Method": "MERGE"
        },
        data: JSON.stringify({
            __metadata: {
                type: "SP.Data.LeadGenerateListItem"
            },          
                        Opportunity : opportunity
                         
                        }), 
                        
             success: function(data) {
             alert('Oportunity Status Updated successfully!');
             
             window.location.href = "https://awcsoftwarenoida.sharepoint.com/sites/SalesCRM_UAT/Pages/MyLeads.aspx";
           
           
            },
        error: function(xhr, status, error) {
            alert("failed");
        }
    });
    }
}



////////////// Delete Document from lib
function deleteDocument(ItemId) 

{

$.ajax({

        url: _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/GetByTitle('LeadGenerateDocuments')/items(" + ItemId+ ")",

        method: "POST",

        headers: {

            "accept": "application/json;odata=verbose",

            "content-type": "application/json;odata=verbose",

            "X-RequestDigest": $("#__REQUESTDIGEST").val(),

            "IF-MATCH": "*",

            "X-HTTP-Method": "DELETE"

        },

        success: function(data) {

 

            alert("item delete");

            location.reload();

            },

        error: function(error) {

            console.log(JSON.stringify(error));

        }

    })

}




