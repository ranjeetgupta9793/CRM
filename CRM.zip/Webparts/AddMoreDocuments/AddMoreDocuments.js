﻿var LeadNumber;
$(document).ready(function(){

$("#submit").click(function () { 
LeadNumber=$("#txtleadgn").val();
 uploadFile();

 
 });

});

function uploadFile(OHR,claimid,currentYearMonthDate) {  
      	var data = [];  
       	var fileArray = [];



        // there is a file input with the ID `file_input ...
        var files = document.getElementById("getFile").files;
        console.log(files);
        for (var i = 0; i < files.length; i++)
        {
            console.log(files[i].name);
            fileArray.push({ "Attachment": files[i] });    	
        }
         console.log("fileArray "+fileArray);
		//var arraycount = fileArray.length;
		if (fileArray.length == 0)
		{
			alert("Please attach all relevant documents !");
			return false;
		}

		/*var validatefile = Checkfiles();
		if(validatefile == false)
		{
			alert('Upload xlsx and xls file only');
			return false;
		} */     		
        data.push({    
             "Files": fileArray
      	});   
    createNewItemWithAttachments("LeadGenerateDocuments", data);         
}  
 var createNewItemWithAttachments = function (listName, listValues) {
        var fileCountCheck = 0;  
        var fileNames;
         
        /*beforeSend:function(){
            //alert("xyz");
              
               },*/
                
        //var context = new SP.ClientContext.get_current();  
       // var dfd = $.Deferred();  
       return new Promise(function (resolve, reject){
        //var targetList = context.get_web().get_lists().getByTitle(listName);  
        //context.load(targetList);  
        //var itemCreateInfo = new SP.ListItemCreationInformation();  
        //var listItem = targetList.addItem(itemCreateInfo);  
        //listItem.set_item("Title",listValues[0].Title);          
         //listItem.update();  
         //context.executeQueryAsync(  
           //function () {  
               //var id = listItem.get_id();  
                //currentlistitemid=listItem.get_id();
                console.log(listValues[0].Files.length);
               if (listValues[0].Files.length != 0) {  
                   if (fileCountCheck <= listValues[0].Files.length - 1) {  
                       loopFileUpload(listName, listValues, fileCountCheck).then(  
                           function () {  
                           },  
                           function (sender, args) {  
                               console.log("Error uploading");  
                               reject(sender, args);  
                           }  
                       );  
                   }  
               }  
               else {  
                   resolve(fileCountCheck);  
               }  
          // },  
           //function (sender, args) {
             //  alert(args.get_message());  
            //   console.log('Error occured' + args.get_message());  
           //}  
      // );    
       });
   }  
 
  function loopFileUpload(listName, listValues, fileCountCheck) {  
       //var dfd = $.Deferred();
       $(".loader").show();
       return new Promise(function (resolve, reject){
       uploadFileHolder(listName, listValues[0].Files[fileCountCheck].Attachment).then(  
           function (data) {  
           		//alert("uploadFileHolder function Then hit");
               //var objcontext = new SP.ClientContext();  
               //var targetList = objcontext.get_web().get_lists().getByTitle(listName);  
               //var listItem = targetList.getItemById(id);  
              // objcontext.load(listItem);  
               //objcontext.executeQueryAsync(function () { 
                  
                   console.log("Reload List Item- Success");  
                   fileCountCheck++;  
                   if (fileCountCheck <= listValues[0].Files.length - 1) {  
                       //alert('In If');
                       loopFileUpload(listName, listValues, fileCountCheck);  
                   } else 
                   {  
                        $(".loader").hide();
                        //alert(fileCountCheck + ": Files uploaded");
                        //alert("Data Uploaded Successfully");
                        location.reload();  
                       // var attcount += fileCountCheck;  
                        //if (arraycount == attcount) { 
                            //if (window.parent.eval("window.waitDialog").close(0)) setTimeout(function () { window.parent.eval("window.waitDialog").close(0); window.location.replace(_spPageContextInfo.siteAbsoluteUrl + "/Lists/QuotationApproval/AllItems.aspx"); }, 3000); 
						//alert("Data Uploaded Successfully"); location.reload();
                        //}  
  
                    }  
                   // alert("Data Sumitted successfully. !!!"); 
                 
                //},  
                //function (sender, args) {  
                 //   console.log("Reload List Item- Fail" + args.get_message());  
                //});  
  
            },  
            function (sender, args) {  
                console.log("Not uploaded");  
                reject(sender, args);  
            }  
       );  
       }); 
   }  
  
    function uploadFileHolder(listName, file) {  
		//alert('In uploadFileHolder');       
		// var deferred = $.Deferred();  
         return new Promise(function (resolve, reject){
        var fileName = LeadNumber+"_"+file.name;  
        //debugger;
       // alert(fileName);
        getFileBuffer(file).then(  
            function (buffer) { 
            	//alert(file.name);
            	var bytes = new Uint8Array(buffer);
                var content = new SP.Base64EncodedByteArray(); 
                for (var b = 0; b < bytes.length; b++) {
                    content.append(bytes[b]);
                }
                
		var xhttp;
                //var payload = { 'logonName': currentUserPrincipalName};
                if (window.XMLHttpRequest) {
                                    // code for modern browsers
                                    xhttp = new XMLHttpRequest();
                                } else {
                                    // code for old IE browsers
                                    xhttp = new ActiveXObject("Microsoft.XMLHTTP");
                                }
                                xhttp.onload = function() {
                        if (this.readyState == 4 && this.status >= 200 && this.status < 400) {
                        var upload_response = JSON.parse(this.responseText);
                            post_cors(upload_response).then(function(data){});//function for inserting metadata of a document
                            //alert(this.responseText);
                            resolve(this.responseText);

                       }else{
                               alert(this.responseText);
                       }
                    };
                    xhttp.onerror = function() {
                                                alert(this.responseText);
                                };
                    xhttp.open("POST", _spPageContextInfo.webAbsoluteUrl+"/_api/web/getfolderbyserverrelativeurl('"+_spPageContextInfo.webServerRelativeUrl+"/LeadGenerateDocuments/')/files/add(overwrite=true, url='"+fileName+"')?$expand=ListItemAllFields",true);
                    xhttp.setRequestHeader('Content-Type','application/json; odata=verbose');
                    xhttp.setRequestHeader('Accept','application/json; odata=verbose');
		    //xhttp.setRequestHeader('content-length', buffer.byteLength);
                    xhttp.setRequestHeader('X-RequestDigest',document.getElementById('__REQUESTDIGEST').value);
                    xhttp.send(buffer);
            },  
            function (err) {  
                reject(err);  
            }  
        );  
        }); 
    }  
 function getFileBuffer(file) {
        //var deferred = jQuery.Deferred();
	return new Promise(function (resolve, reject){
	var reader = new FileReader();
        reader.onloadend = function (e) {
            resolve(e.target.result);
        }
        reader.onerror = function (e) {
            reject(e.target.error);
        }
        reader.readAsArrayBuffer(file);
	});

    }
    
    var counter = 0;
  function post_cors(uploadResponse){
    //console.log(uploadResponse);
   return new Promise(function (resolve, reject){
        var attachment_Id = uploadResponse.d.ListItemAllFields.ID;
        console.log("attachment_Id is  "+attachment_Id);
        var itemProperties = { 
            "__metadata" : {"type": "SP.ListItem"},          
        "LeadGenerateNumber":LeadNumber
        };
        counter++;
        var data = JSON.stringify(itemProperties);
        var xhr = new XMLHttpRequest();
        xhr.open('POST', _spPageContextInfo.webAbsoluteUrl+"/_api/Web/lists/getbytitle('LeadGenerateDocuments')/items("+attachment_Id+")");
        xhr.setRequestHeader("Content-type", "application/json;odata=verbose");
        xhr.setRequestHeader("Accept", "application/json; odata=verbose");
        xhr.setRequestHeader("X-RequestDigest", document.querySelector('#__REQUESTDIGEST').value);
        xhr.setRequestHeader("X-Http-Method", "MERGE");
        xhr.setRequestHeader("If-Match", "*");
        xhr.onload = function() {
                        if (this.readyState == 4 && this.status >= 200 && this.status < 400) {
                            console.log(this.responseText);
                            resolve(this.responseText);
                            console.log(counter);
                        }else{
                               alert(this.responseText);
                        }
                    };
        xhr.onerror = function() {
                                    reject(this.responseText);
                                };
        xhr.send(data);
        return xhr;
   }); 
}

 
  

